package ch.systemsx.sybit.crkwebui.client.commons.gui.data;

public enum TooltipXPositionType {
	LEFT,
	RIGHT;
}
